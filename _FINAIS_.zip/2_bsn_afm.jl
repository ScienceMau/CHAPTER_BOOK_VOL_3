using DynamicalSystems, Statistics, OrdinaryDiffEq, DelimitedFiles, DataStructures

# Modelo matemático ajustado
@inline @inbounds function MathModel(u, par, t)
   d1  = 0.01
   D1  = -0.148967
   C11 = -4.59228e-5
   C12 = 0.149013
   eta = 0.01
   omega = 1.0
   E1 = 1.57367
   cv = par[1]



    den1 = (1 - u[1] - eta * sin(omega * t))
    
    # Proteção contra divisão por zero
    if abs(den1) < 1e-10
        den1 = sign(den1) * 1e-10
    end

   du1 = u[2]
   du2 = -d1*u[2]-u[1]+D1+C11/(den1)^8+C12/(den1)^2-(cv*u[2]/(den1)^3)+eta*omega^2*E1*sin(omega*t)
    
   return SVector{2}(du1, du2)
end

function basins_of_attraction_calculys(u0, x0, y0, p)
    diffeq = (alg = Vern9(), abstol = 1e-9, reltol = 1e-9)
    ds = ContinuousDynamicalSystem(MathModel, u0, [p]; diffeq)
    
    # Ajuste dos parâmetros do mapper
    mapper = AttractorsViaRecurrences(ds, (x0, y0); 
        sparse = false,
        Δt = 0.01,
        Ttr = 1000,  # Tempo de transiente
        mx_chk_att = 100,  # Número máximo de verificações
        mx_chk_lost = 100,  # Número máximo de verificações para atratores perdidos
        #successive_checks_attractor = 20,  # Verificações sucessivas
        #successive_checks_basin = 10  # Verificações sucessivas para bacia
    )
    
    basins, attractors = basins_of_attraction(mapper; show_progress = true)
    return basins, attractors
end

function Basins_Analysis(basins, len_x, len_y)
    F = counter(basins)
    attractor = collect(keys(F))
    NCI = collect(values(F))
    FracNCI = NCI/(len_x*len_y)

    Ve, Ne, D = basins_fractal_dimension(basins)
    eps, Neps, ALPHA = uncertainty_exponent(basins)
    Sb, Sbb = basin_entropy(basins)
    return NCI, FracNCI, ALPHA, Sb, Sbb, D
end

function main_analysis()
    p_range = range(0.01, 0.1, length=100)
    results = []
    
    for (i, p_val) in enumerate(p_range)
        println("Processando p = $p_val ($i/$(length(p_range)))")
        
        x0 = range(-0.9, 0.9, length=300)
        y0 = range(-0.9, 0.9, length=300)
        u0 = [0.0, 0.0]
        
        try
            basins, attractors = basins_of_attraction_calculys(u0, x0, y0, p_val)
            
            NCI, FracNCI, ALPHA, Sb, Sbb, D = Basins_Analysis(basins, 300, 300)
            
            # Salvar resultados para este parâmetro
            push!(results, (p_val, NCI, FracNCI, ALPHA, Sb, Sbb, D))
            
            println("Resultados para p = $p_val:")
            println("NCI: $NCI")
            println("Fração NCI: $FracNCI")
            println("Expoente de incerteza: $ALPHA")
            println("Entropia da bacia: $Sb")
            println("Dimensão fractal: $D")
            
        catch e
            println("Erro ao processar p = $p_val:")
            showerror(stdout, e)
            println()
            push!(results, (p_val, NaN, NaN, NaN, NaN, NaN, NaN))
        end
    end
    
    # Salvar todos os resultados
    open("results_summary.txt", "w") do io
        println(io, "p\tNCI\tFracNCI\tALPHA\tSb\tSbb\tD")
        for r in results
            println(io, join(r, "\t"))
        end
    end
    
    return results
end

# Executar a análise
final_results = main_analysis()