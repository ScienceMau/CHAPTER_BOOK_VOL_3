using DynamicalSystems, Statistics, SharedArrays, OrdinaryDiffEq, DelimitedFiles, DataStructures

@inline @inbounds function MathModel(u, par, t)

    d    = 0.15
    beta = -1.0
    w    = par[1];#1.0
    f0 = 0.2
    a0 = 0.2
    b0 = 0.2

    du1 = u[2]
    du2 = -d*u[2]-beta*u[1]-u[1]^3+f0*cos(w*t+a0*sin(b0*w*t))
	return SVector{2}(du1, du2);
end


function calculus(u0, parameter0, TIME, TRANSIENTE)
    Lyap = SharedMatrix{Float64}(length(parameter0), length(u0));
    for i = 1:1:length(parameter0)
        diffeq    = (alg = Vern9(), abstol = 1e-9, reltol = 1e-9)
        ds        = ContinuousDynamicalSystem(MathModel,u0,[parameter0[i]];diffeq)
        tr,t      = trajectory(ds,TIME; Δt = 0.01, Ttr = TRANSIENTE)
        #writedlm("$(i)_TS.txt", [tr[:,1] tr[:,2] tr[:,3] tr[:,4] tr[:,5]])
        Lyap[i,:] = lyapunovspectrum(ds,50000; Δt=0.01, Ttr= 5000)
        println(i)
    end
    writedlm("_Lyapunov_.txt", [parameter0 Lyap])
end

function scatter_attractors(basins, attractors,i)
    #for k in keys(attractors)
    #    x, y = columns(attractors[k])
    #    writedlm("$(i)_attractor_$(k)_.txt", [x y])
    #end
    writedlm("$(i)_basins_.txt", basins)
end


function Basins_Analisys(basins, len_x, len_y)
	F = counter(basins)
	attractor = collect(keys(F))
	NCI = collect(values(F))
	FracNCI = NCI/(len_x*len_y)

	Ve, Ne, D = basins_fractal_dimension(basins)
	eps, Neps, ALPHA = uncertainty_exponent(basins)
	Sb, Sbb = basin_entropy(basins)
	return NCI, FracNCI, ALPHA, Sb, Sbb, D
end


function basins_of_attraction_calculys(u0,x0,y0, p)
    #x0 = range(-0.9, 0.9, length =500)
    #y0 = range(-0.9, 0.9, length = 500)
    diffeq    = (alg = Vern9(), abstol = 1e-9, reltol = 1e-9)
    ds        = ContinuousDynamicalSystem(MathModel,u0,[p];diffeq)
    #psys   = ProjectedDynamicalSystem(ds, [1, 2], [0])    
    mapper = AttractorsViaRecurrences(ds, (x0, y0);sparse = false, attractor_locate_steps = 1000, consecutive_recurrences = 1000, consecutive_lost_steps = 1000, Δt=0.01, Ttr = 1000)  # Tempo de transiente
        #mx_chk_att = 100,  # Número máximo de verificações
        #mx_chk_lost = 100,  # Número máximo de verificações para atratores perdidos
        #consecutive_recurrences = 1000,
        #attractor_locate_steps = 1000,
        #consecutive_lost_steps = 500)
        #successive_checks_attractor = 20,  # Verificações sucessivas
        #successive_checks_basin = 10  # Verificações sucessivas para bacia
    #)
    basins, attractors = basins_of_attraction(mapper; show_progress = false)

    return basins, attractors
end

#GRID_SIZE = 500

p =range(0.001, 1.0, length = 800)
A = SharedMatrix{Float64}(length(p),1);
B = SharedMatrix{Float64}(length(p),1);
C = SharedMatrix{Float64}(length(p),1);
D = SharedMatrix{Float64}(length(p),1);
E = SharedMatrix{Float64}(length(p),1);
F = SharedMatrix{Float64}(length(p),1);
Lyap = SharedMatrix{Float64}(length(p),2);
A6 = SharedMatrix{Float64}(length(p),1);

VA = Any[]
VB = Any[]
VC = Any[]

#calculus([0.0,0.0,0.0,0.0], p, 10000, 5000)
i=502
#for i =1:1:length(p)
    NN = 1000
    x0 = range(-2.5, 2.5, length = NN)
    y0 = range(-2.5, 2.5, length = NN)
    u0 = [0.0,0.0]
    
    basins, attractors = basins_of_attraction_calculys(u0,x0 ,y0, p[i])
    scatter_attractors(basins, attractors,i)
    
    #F1, F2, A[i], B[i], C[i], D[i] = Basins_Analisys(basins, NN, NN)
    #push!(VA,F1)
    #push!(VB,F2)
    #push!(VC, maximum(basins))
    #@show F1, F2 
    #@show A[i], B[i], C[i], D[i], i, p[i], maximum(basins)

#end
writedlm("_RESULTADOS_F1.txt", VA)
writedlm("_RESULTADOS_F2.txt", VB)
writedlm("_RESULTADOS_F3.txt", VC)
writedlm("_FINAIS_.txt", [A B C D])